import SwiftUI

@main
struct BrewMateApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
