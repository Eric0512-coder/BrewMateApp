//
//  BrewMateAppTests.swift
//  BrewMateAppTests
//
//  Created by 钱羿臣 on 2025/5/13.
//

import Testing
@testable import BrewMateApp

struct BrewMateAppTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
